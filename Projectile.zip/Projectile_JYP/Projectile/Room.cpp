
#include "Room.h"




Room::Room()
{
	gravitational_acc_y_ = -9.8;	// -9.8 m/s^2
	wind_acc_x_ = 5.0;              // Vw
	air_density_ = 1.2;             // 0m -> 1.225kg/m^3, 305m -> 1.189kg/m^3

	// World height
	height_ = 50;	// 50m
	
	// World width
	width_ = 90; // 90m
	

	// Fence
	vertical_fence_pos_x_ = 45;
	vertical_fence_height_ = 30;

	// Fence2
	vertical_fence2_pos_x_ = 90 * 3/4;
	vertical_fence2_height_ = 15;

	// Box
	box_pos_x1_ = 33;
	box_pos_x2_ = 43;
	box_height_ = 10;
}


