#pragma once

#include "SDL.h"

class Room 
{
public:
	Room();

	double width() const { return width_; }
	double height() const { return height_; }
	double ground_height() const { return 0; }
	double gravitational_acc_y() const { return gravitational_acc_y_; }
	
	double wind_acc_x() const { return wind_acc_x_; }
	double air_density() const { return air_density_; }
	

	// Fence
	double vertiacal_fence_pos_x() const { return vertical_fence_pos_x_; }
	double vertiacal_fence_height() const { return vertical_fence_height_; }

	// Fence2
	double vertiacal_fence2_pos_x() const { return vertical_fence2_pos_x_; }
	double vertiacal_fence2_height() const { return vertical_fence2_height_; }
	
	// Box
	double box_pos_x1() const { return box_pos_x1_; }
	double box_pos_x2() const { return box_pos_x2_; }
	double box_height() const { return box_height_; }

protected:
	
	double width_;
	double height_;


	// Fence
	double vertical_fence_pos_x_;
	double vertical_fence_height_;

	// Fence2
	double vertical_fence2_pos_x_;
	double vertical_fence2_height_;

	// Box
	double box_pos_x1_;
	double box_pos_x2_;
	double box_height_;

	double gravitational_acc_y_;
	double wind_acc_x_;
	double air_density_;
};

