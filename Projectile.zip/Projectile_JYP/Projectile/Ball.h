#pragma once

#include "SDL.h"
#include "Room.h"

#define PI 3.14

class Ball
{
public:
	Ball(double radius, Room* room);

	void Reset();
	virtual void Update(unsigned int elapsed_time_ms, int ball_num, Ball **ball);
	void Launch(double initial_force_x, double initial_force_y);
	void LeftWind();
	void RightWind();
	bool b_ball_collision();

	void velocity(double x, double y) { v_[0] = x; v_[1] = y; }
	double radius() const { return radius_; }
	double mass() const { return mass_; }
	double coeff_of_restitution() { return coeff_of_restitution_; }
	double body_area() const { return body_area_; }
	double drag_coefficient() const { return drag_coefficient_; }

	double pos_x() const { return p_[0]; }
	double pos_y() const { return p_[1]; }

protected:
	Room* room_;
	int i, j, ball_num;
	double tmp1, tmp2;
	double dx, dy, dtt, d, sq;
	double vp_a, vp_b;
	double ap, an, vn_a, vn_b;
	double p;
	
	double radius_;	// meter
	double mass_;	// kg
	double coeff_of_restitution_; // from 0 o 1
	double coeff_of_friction_;
	double elastic_modulus_;
	double box_coeff_of_restitution_; // like sponge

	double body_area_;
	double drag_coefficient_;

	double drag_f[2];
	double drag_a[2];

	bool b_left_wind, b_right_wind;
	bool b_ball_collision_;

	// position
	double p_[2];	// x, y

	// velocity
	double v_[2];	// x, y

	double vw;       // wind velocity
};

